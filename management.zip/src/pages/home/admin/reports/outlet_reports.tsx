import { Outlet } from "react-router-dom";

export default function ReportsOutlet() {
  return <Outlet />;
}
