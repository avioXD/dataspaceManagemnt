export default function ClassReport() {}
