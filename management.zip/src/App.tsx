import React from "react";
import MainRouter from "./main_router";
function App() {
  return (
    <div className="App">
      <MainRouter />
    </div>
  );
}

export default App;
